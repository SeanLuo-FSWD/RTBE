-- AlterTable
ALTER TABLE "User" ADD COLUMN     "profileImg" TEXT;
